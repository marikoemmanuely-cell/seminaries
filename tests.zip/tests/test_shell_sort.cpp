// test_shell_sort.cpp
#include "pch.h"
#include "../seminar3/shell_sort.h"
#include "sort_test_common.h"
SORT_TEST_SUITE(ShellSort, shellSort)