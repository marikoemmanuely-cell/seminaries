// test_binary_insertion_sort.cpp
#include "pch.h"
#include "../seminar2/binary_insertion_sort.h"
#include "sort_test_common.h"
SORT_TEST_SUITE(BinaryInsertionSort, binaryInsertionSort)