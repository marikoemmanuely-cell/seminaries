// test_optimized_bubble_sort.cpp
#include "pch.h"
#include "../seminar1/optimized_bubble_sort.h"
#include "sort_test_common.h"
SORT_TEST_SUITE(OptimizedBubbleSort, optimizedBubbleSort)