// test_exchange_sort.cpp
#include "pch.h"
#include "../seminar1/exchange_sort.h"
#include "sort_test_common.h"
SORT_TEST_SUITE(ExchangeSort, exchangeSort)