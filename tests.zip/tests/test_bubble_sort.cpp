// test_bubble_sort.cpp
#include "pch.h"
#include "../seminar1/bubble_sort.h"
#include "sort_test_common.h"
SORT_TEST_SUITE(BubbleSort, bubbleSort)