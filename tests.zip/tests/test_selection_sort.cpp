// test_selection_sort.cpp
#include "pch.h"
#include "../seminar1/selection_sort.h"
#include "sort_test_common.h"
SORT_TEST_SUITE(SelectionSort, selectionSort)