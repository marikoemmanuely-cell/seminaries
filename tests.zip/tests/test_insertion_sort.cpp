// test_insertion_sort.cpp
#include "pch.h"
#include "../seminar1/insertion_sort.h"
#include "sort_test_common.h"
SORT_TEST_SUITE(InsertionSort, insertionSort)